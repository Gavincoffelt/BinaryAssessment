#pragma once
#include <iostream>
#include <string> 
using namespace std;
struct Monster {
	string IDnumber;
	string HP;
	string type;
	string description;
	string name;
	

};






